Libraries needed:
JDK-21 JavaFX21
charm-glisten-4.4.1

The project can be imported into your IDE of choice (preferably netBeans) from the ZIP file.