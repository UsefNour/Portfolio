from flask import *
from functools import wraps

def role_required(*roles):
    def role_checker(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if session.get("role") in roles:
                return f(*args, **kwargs)
            elif session.get("role") is not None:
                return redirect(url_for("manage", msg = f"Access to {request.path} denied"))
            else:
                return redirect("/index/")
        return wrapper
    return role_checker