import sqlite3
from os import path

web_path = path.abspath(path.join(path.dirname(__file__), '..', 'web'))
db_path = path.join(web_path, 'horizon.db')

existing = path.isfile(db_path)
db = sqlite3.connect(db_path, check_same_thread=False)
db.row_factory = sqlite3.Row

if not existing:
    db_init_path = path.join(path.dirname(__file__), '..', 'db_init.sql')
    with open(db_init_path, "r") as f:
        c = db.cursor()
        s = f.read()
        c.executescript(s)
        db.commit()
        c.close()

class Cursor():

    def __enter__(self):
        self.c = db.cursor()
        return self.c

    def __exit__(self, *args):
        db.commit()
        self.c.close()