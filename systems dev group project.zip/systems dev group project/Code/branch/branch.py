import sys
from os import path
sys.path.append(path.abspath("."))
sys.path.append(path.abspath("./components/"))

from flask import *

from components.base import *
from components.account import acc
from components.inventory import inv
from components.menu import menu
from components.order import ord
from components.reservation import res

from components.u_menu import u_menu
from components.u_order import u_ord
from components.u_reservation import u_res

app = Flask(__name__)
app.root_path = path.dirname(__file__) + "/web"

app.register_blueprint(acc)
app.register_blueprint(inv)
app.register_blueprint(menu)
app.register_blueprint(ord)
app.register_blueprint(res)

app.register_blueprint(u_menu)
app.register_blueprint(u_ord)
app.register_blueprint(u_res)

app.secret_key = b"ald"

@app.route('/index/')
def index():
    return render_template("index.html")

@app.route('/', methods = ["GET"])
@role_required("A", "E", "U")
def manage():
    return render_template("manage.html", msg = request.args.get("msg"))

@app.route('/logout/')
def logout():
    session.clear()
    return redirect('/index/')

if __name__ == '__main__':
    app.run(port = 5070, debug = True)