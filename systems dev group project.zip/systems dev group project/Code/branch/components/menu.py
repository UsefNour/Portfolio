from flask import *
from .base import *
from .branch_db import Cursor

menu = Blueprint('menu', __name__)


class MenuCategory:
    def __init__(self, cat_name, cat_id = None):
        self.cat_name = cat_name
        self.cat_id = cat_id

    def to_dict(self):
        return {
            'cat_id': self.cat_id,
            'cat_name': self.cat_name
        }

    def view_menu_category(cat_id, branch):
        with Cursor() as c:
            c.execute("SELECT * FROM menu_category WHERE id = ? AND branch_id = ?", (cat_id, branch,))
            category = c.fetchone()
            return category

    def view_categories(branch):
        with Cursor() as c:
            c.execute("SELECT id, name FROM menu_category WHERE branch_id = ?", (branch,))
            category_list = c.fetchall()
            return [MenuCategory(cat_name = row['name'], cat_id = row['id']) for row in category_list]
        
    def create_category(category, branch):
        with Cursor() as c:
            c.execute("INSERT INTO menu_category (name, branch_id) VALUES (?, ?)", (category.cat_name, branch,))

    def update_category(name, cat_id, branch):
        with Cursor() as c:
            c.execute("UPDATE menu_category SET name = ?, branch_id = ? WHERE id = ?", (name, branch, cat_id,))

    def delete_category(cat_id, branch):
        with Cursor() as c:
            c.execute("DELETE FROM menu_item WHERE category_id = ? AND branch_id = ?", (cat_id, branch,))

            c.execute("DELETE FROM menu_category WHERE id = ? AND branch_id = ?", (cat_id, branch,))


class MenuItem:
    def __init__(self, price, item_name, desc, all_gens, category = None, item_id = None):
        self.price = price
        self.item_name = item_name
        self.desc = desc
        self.all_gens = all_gens
        self.category = category
        self.item_id = item_id

    def to_dict(self):
        return {
            'item_id': self.item_id,
            'price': self.price,
            'item_name': self.item_name,
            'desc': self.desc,
            'all_gens': self.all_gens
        }

    def view_menu_item(item_id, branch):
        with Cursor() as c:
            c.execute("SELECT * FROM menu_item WHERE id = ? AND branch_id = ?", (item_id, branch,))
            item = c.fetchone()
            return item

    def view_items_by_category(cat_id, branch):
        with Cursor() as c:
            c.execute("SELECT id, price, name, description, allergens FROM menu_item WHERE category_id = ? AND branch_id = ?", (cat_id, branch))
            item_list = c.fetchall()
            return [MenuItem(price = row['price'], item_name = row['name'], desc = row['description'], all_gens = row['allergens'], item_id = row['id']) for row in item_list]

    def create_item(item, branch):
        with Cursor() as c:
            c.execute("INSERT INTO menu_item (category_id, price, name, description, allergens, branch_id) VALUES (?, ?, ?, ?, ?, ?)", (item.category, item.price, item.item_name, item.desc, item.all_gens, branch,))

    def update_item(price, name, desc, all_gens, item_id, branch):
        with Cursor() as c:
            c.execute("UPDATE menu_item SET price = ?, name = ?, description = ?, allergens = ? WHERE id = ? AND branch_id = ?", (price, name, desc, all_gens, item_id, branch,))

    def delete_item(item_id, branch):
        with Cursor() as c:
            c.execute("DELETE FROM menu_item WHERE id = ? AND branch_id = ?", (item_id, branch,))


@menu.route('/<branch>/m_menu/', methods = ["POST","GET"])
@role_required("A", "E")
def m_menu(branch):
    categories = [category.to_dict() for category in MenuCategory.view_categories(branch)]
    items_by_category = {
        cat['cat_id']: [item.to_dict() for item in MenuItem.view_items_by_category(cat['cat_id'], branch)]
        for cat in categories
    }
    return render_template('m_menu.html', categories = categories, items_by_category = items_by_category, branch = branch)


@menu.route('/<branch>/create_menu_category/', methods = ["POST","GET"])
@role_required("A", "E")
def create_menu_category(branch):
    if request.method == 'POST':
        name = request.form.get('name')

        category = MenuCategory(name)
        MenuCategory.create_category(category, branch)

        return redirect(url_for('menu.m_menu', branch = branch))
    

@menu.route('/<branch>/create_menu_item/', methods = ["POST","GET"])
@role_required("A", "E")
def create_menu_item(branch):
    if request.method == 'POST':
        category = request.form.get('category')
        price = request.form.get('price')
        name = request.form.get('name')
        desc = request.form.get('desc')
        all_gens = request.form.get('all_gens')

        item = MenuItem(price, name, desc, all_gens, category)
        MenuItem.create_item(item, branch)

        return redirect(url_for('menu.m_menu', branch = branch))
    

@menu.route('/<branch>/update_menu_category/<string:cat_id>/', methods = ["POST","GET"])
@role_required("A", "E")
def update_menu_category(cat_id, branch):
    if request.method == 'POST':
        name = request.form.get('name')

        MenuCategory.update_category(name, cat_id, branch)
        return redirect(url_for('menu.m_menu', branch = branch))
    
    category = MenuCategory.view_menu_category(cat_id, branch)
    return render_template('update_menu_category.html', category = category, branch = branch)


@menu.route('/<branch>/update_menu_item/<string:item_id>/', methods = ["POST","GET"])
@role_required("A", "E")
def update_menu_item(item_id, branch):
    if request.method == 'POST':
        price = request.form.get('price')
        name = request.form.get('name')
        desc = request.form.get('desc')
        all_gens = request.form.get('all_gens')

        MenuItem.update_item(price, name, desc, all_gens, item_id, branch)
        return redirect(url_for('menu.m_menu', branch = branch))
    
    item = MenuItem.view_menu_item(item_id, branch)
    return render_template('update_menu_item.html', item = item, branch = branch)


@menu.route('/<branch>/delete_menu_category/<string:cat_id>/', methods = ["POST","GET"])
@role_required("A", "E")
def delete_menu_category(cat_id, branch):
    if request.method == 'POST':
        MenuCategory.delete_category(cat_id, branch)

        return redirect(url_for('menu.m_menu', branch = branch))
    

@menu.route('/<branch>/delete_menu_item/<string:item_id>/', methods = ["POST","GET"])
@role_required("A", "E")
def delete_menu_item(item_id, branch):
    if request.method == 'POST':
        MenuItem.delete_item(item_id, branch)

        return redirect(url_for('menu.m_menu', branch = branch))