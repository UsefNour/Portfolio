#!C:\Users\amirh\AppData\Local\Programs\Python\Python311\python.exe

import cgi
import random
import mysql.connector

# Generate a random membership ID consisting of a 6-digit number
def generate_membership_id():
    return str(random.randint(100000, 999999))

# Connect to MySQL
def connect_to_database():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='SQL@pass5637',
        database='callingcomp'
    )

# Insert form data into the database
def insert_form_data(form_data):
    try:
        connection = connect_to_database()
        cursor = connection.cursor()

        # Generate a random membership ID
        membership_id = generate_membership_id()

        # Insert data into the table
        sql = "INSERT INTO sign_up (membership_id, email, password, date_of_birth) VALUES (%s, %s, %s, %s)"
        values = (membership_id, form_data['enteryouremail'].value, form_data['enteryourpassword'].value, form_data['enteryourdateofbirth'].value)
        cursor.execute(sql, values)

        # Commit the changes
        connection.commit()
        cursor.close()
        connection.close()

        return membership_id  # Return the generated membership ID
    except mysql.connector.Error as error:
        print("Content-type:text/html\r\n\r\n")
        print("<html>")
        print("<head>")
        print("<title>Sign Up</title>")
        print("</head>")
        print("<body>")
        print("<h1>Sign Up Failed</h1>")
        print("<p>Sorry, an error occurred while processing your request.</p>")
        print("<p>Error Details: {}</p>".format(error))
        print("</body>")
        print("</html>")
        return None

# Get form data
form = cgi.FieldStorage()

# Insert form data into the database
membership_id = insert_form_data(form)
if membership_id:
    print("Content-type:text/html\r\n\r\n")
    print("<html>")
    print("<head>")
    print("<title>Sign Up</title>")
    print("</head>")
    print("<body>")
    print("<h1>Sign Up Successful</h1>")
    print("<p>Your membership ID is: {}</p>".format(membership_id))
    print('<form action="services-details.html">')
    print('<input type="submit" value="Go to Services Details">')
    print('</form>')
    print("</body>")
    print("</html>")
