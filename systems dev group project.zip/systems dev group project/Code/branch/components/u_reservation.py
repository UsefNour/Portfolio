from flask import *
from .base import *
from .reservation import *

u_res = Blueprint('u_reservation', __name__)


@u_res.route('/u_reserve_list/', methods = ["POST","GET"])
@role_required("U")
def view_u_res_list():
    reservations = Reservation.view_reservation_user(session["name"])
    return render_template("reserve_list.html", reservations = reservations)


@u_res.route('/select_reserve_branch/', methods = ["POST","GET"])
@role_required("U")
def select_reserve_branch():
    with Cursor() as c:
        c.execute("SELECT * from branch")
        branches = c.fetchall()

    return render_template("select_reserve_branch.html", branches = branches)


@u_res.route('/<branch>/u_reserve/', methods = ["POST","GET"])
@role_required("U")
def u_reserve(branch):
    return render_template("reserve.html", name = session["name"], branch = branch)


@u_res.route('/<branch>/create_u_reservation/', methods = ["POST","GET"])
@role_required("U")
def create_u_reservation(branch):
    if request.method == 'POST':
        amount = request.form.get('amount')
        name = request.form.get('name')
        datetime = request.form.get('datetime')

        available_tables = Table.check_availability(amount, datetime, branch)

        if isinstance(available_tables, str):
            flash(available_tables, 'error')
            return redirect(url_for('u_reservation.u_reserve', branch = branch))
        else:
            return render_template("create_U_reserve.html", tables = available_tables, amount = amount, name = name, datetime = datetime, branch = branch)
        

@u_res.route('/<branch>/confirm_u_reservation/', methods = ["POST","GET"])
@role_required("U")
def confirm_u_reservation(branch):
    if request.method == 'POST':
        table_id = request.form.get('table_id')
        amount = request.form.get('amount')
        name = request.form.get('name')
        datetime = request.form.get('datetime')

        reservation = Reservation(table_id, amount, name, datetime)

        Reservation.create_reservation(reservation, branch)

        return redirect('/u_reserve_list/')