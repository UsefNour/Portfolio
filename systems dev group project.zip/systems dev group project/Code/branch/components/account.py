from .branch_db import Cursor
from passlib.hash import sha256_crypt as sha256
from flask import *
from .base import *

acc = Blueprint('account', __name__)


class Account:
    def __init__(self, id, forename, surname, password, role):
        self.id = id
        self.forename = forename
        self.surname = surname
        self.password = password
        self.role = role

    def view_accounts():
        with Cursor() as c:
            admin_role = "A"
            employee_role = "E"
            c.execute("SELECT * FROM account WHERE role = ? OR role = ?", (admin_role, employee_role))
            accounts = c.fetchall()
            return [Account(id = row["id"], forename = row["forename"], surname = row["surname"], password = row["security_hash"], role = row["role"]) for row in accounts]
        
    def view_account(account_id):
        with Cursor() as c:
            c.execute("SELECT * FROM account WHERE id = ?", (account_id,))
            accounts = c.fetchall()
            return [Account(id = row["id"], forename = row["forename"], surname = row["surname"], password = row["security_hash"], role = row["role"]) for row in accounts]


@acc.route('/login/', methods = ["POST","GET"])
def login():
    if request.method == "GET":
        return render_template("index.html")

    elif request.method == "POST":
        print(*request.form)
        forename = request.form.get("forename","").lower()
        surname = request.form.get("surname","").lower()
        password = request.form.get("password")

        with Cursor() as c:
            c.execute("SELECT * FROM account WHERE forename = ? AND surname = ?", (forename, surname,))
            r = c.fetchone()
            if r is None or not sha256.verify(password, r["security_hash"]):
                flash("Invalid credentials. Please try again.")
                return render_template("index.html")
            
            bid = r["branch_id"]

            c.execute("SELECT name FROM branch WHERE id = ?", (bid,))
            branch_result = c.fetchone()
            branch_name = branch_result['name']

            session["id"] = r["id"]
            session["role"] = r["role"]
            session["forename"] = forename
            session["surname"] = surname
            session["name"] = forename + " " + surname
            session["branch"] = r["branch_id"]
            session["branch_name"] = branch_name
            session['logged_in'] = True
            return redirect("/")


@acc.route('/register/', methods = ["POST","GET"])
def register():
    if request.method == "POST":
        forename = request.form.get("forename","").lower()
        surname = request.form.get("surname","").lower()
        password = request.form.get("password")
        passwordCon = request.form.get("passwordCon")

        if password != passwordCon:
            flash("Password must match. Please try again.")
            return redirect("/register/")
        else:
            with Cursor() as c:
                password_hash = sha256.hash(str(password))
                role = "U"
                branch_id = "0"

                c.execute("INSERT INTO account (forename, surname, security_hash, role, branch_id) VALUES (?, ?, ?, ?, ?)", (forename, surname, password_hash, role, branch_id))
            return redirect("/")
    return render_template("register.html")


@acc.route('/login_page/', methods = ["POST","GET"])
def login_page():
    return render_template("login.html")


@acc.route('/m_account/')
@role_required("A")
def m_account():
    accounts = Account.view_accounts()
    return render_template("m_account.html", accounts = accounts)


@acc.route('/u_account/')
@role_required("U")
def u_account():
    account_id = session["id"]
    return render_template("u_account.html", account_id = account_id)


@acc.route('/user/update_password/<string:account_id>/', methods = ["POST","GET"])
@role_required("U")
def change_user_password(account_id):
    if request.method == 'POST':
        old_password = request.form.get("passwordOld")
        new_password = request.form.get("passwordNew")
        passwordCon = request.form.get("passwordCon")

        with Cursor() as c:
            c.execute("Select * FROM account WHERE id = ?", (account_id,))
            account = c.fetchone()
            if account is None or not sha256.verify(old_password, account["security_hash"]):
                    flash("Invalid credentials. Please try again.")
                    return redirect("/u_account/")
            
        if new_password != passwordCon:
            flash("Password must match. Please try again.")
            return redirect("/u_account/")
        else:
            with Cursor() as c:
                password_hash = sha256.hash(str(new_password))

                c.execute("UPDATE account SET security_hash = ?", (password_hash,))
            return redirect("/")
        
    accounts = Account.view_account(account_id)
    return render_template('update_u_password.html', accounts = accounts)


@acc.route('/admin/update_role/<string:account_id>/', methods = ["POST","GET"])
@role_required("A")
def change_account_role(account_id):
    if request.method == 'POST':
        new_role = request.form.get("role")

        with Cursor() as c:
            c.execute("SELECT role FROM account WHERE id = ?", (account_id,))
            target_role = c.fetchone()["role"]

            if target_role is None:
                return redirect("/m_account/")
            
            with Cursor() as c:
                c.execute("UPDATE account SET role = ? WHERE id = ?", (new_role, account_id,))

            return redirect("/m_account/")
        
    account = Account.view_account(account_id)
    return render_template('update_role.html', accounts = account)


@acc.route('/admin/update_password/<string:account_id>/', methods = ["POST","GET"])
@role_required("A")
def change_account_password(account_id):
    if request.method == 'POST':
        new_password = request.form.get("password")
        hashed = sha256.hash(new_password)

        with Cursor() as c:
            c.execute("SELECT role FROM account WHERE id = ?", (account_id,))
            target_role = c.fetchone()["role"]

            if target_role is None:
                return redirect("/m_account/")
            
            with Cursor() as c:
                c.execute("UPDATE account SET security_hash = ? WHERE id = ?", (hashed, account_id,))

            return redirect("/m_account/")
        
    account = Account.view_account(account_id)
    return render_template('update_password.html', accounts = account)


@acc.route('/admin/create_account/', methods = ["POST"])
@role_required("A")
def create_account():
    fn = request.form.get("forename","").lower()
    sn = request.form.get("surname","").lower()
    role = request.form.get("role")
    password = request.form.get("password")
    hashed = sha256.hash(password)

    with Cursor() as c:
        c.execute("INSERT INTO account (forename, surname, role, security_hash) values (?, ?, ?, ?)", (fn, sn, role, hashed,) )
    return redirect("/m_account/")


@acc.route('/admin/delete_account/<string:account_id>/', methods = ["POST"])
@role_required("A")
def delete_account(account_id):
    if request.method == 'POST':
        with Cursor() as c:
            c.execute("SELECT role FROM account WHERE id = ?", (account_id,))
            target_role = c.fetchone()["role"]

            if target_role is None:
                return redirect("/m_account/")
        
        with Cursor() as c:
            c.execute("DELETE FROM account WHERE id = ?", (account_id,))

        return redirect("/m_account/")